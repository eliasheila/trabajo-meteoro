#include <Wire.h>
#include <Adafruit_BME280.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// BME280 I2C address is 0x76(108)
#define Addr 0x76
Adafruit_BME280 bme;

// LCD Display Configuration
const int SCREEN_WIDTH = 128; // OLED display width, in pixels
const int SCREEN_HEIGHT = 64; // OLED display height, in pixels

// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setup()
{
  // Initialize I2C communication as MASTER
  Wire.begin();

  // Initialize Serial communication, set baud rate = 9600
  Serial.begin(9600);
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { // Address 0x3D for 128x64
    Serial.println(F("SSD1306 allocation failed"));
    while(true);
  }
  // Initialize the LCD
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0, 10);
  
  // Initialize the BME280 sensor
  if (!bme.begin(Addr))
  {
    Serial.println("Could not find a valid BME280 sensor, check wiring!");
    while (1);
  }
  Serial.print("SensorID: ");
  Serial.println(bme.sensorID(), HEX);
}

void loop()
{
  // Read sensor data
  float cTemp = bme.readTemperature();
  float fTemp = cTemp * 1.8 + 32;
  //float pressure = bme.readPressure() / 100.0F; // Convert pressure to hPa
  //float humidity = bme.readHumidity();
  
  // Display data on the LCD
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0, 10);
  // Display static text
  display.print("Temperature in C: ");
  display.println(cTemp);
  display.print("Temperature in Fahrenheit: ");
  display.println(fTemp);
  display.display();

  /*lcd.setCursor(7, 0);
  lcd.print(cTemp, 2);
  lcd.setCursor(7, 1);
  lcd.print(fTemp, 2);
  lcd.setCursor(11, 2);
  lcd.print(pressure, 2);
  lcd.setCursor(11, 3);
  lcd.print(humidity, 2);*/
  
  // Output data to serial monitor
  Serial.print("Temperature in Celsius : ");
  Serial.print(cTemp);
  Serial.println(" C");
  Serial.print("Temperature in Fahrenheit : ");
  Serial.print(fTemp);
  /*Serial.println(" F");
  Serial.print("Pressure : ");
  Serial.print(pressure);
  Serial.println(" hPa");
  Serial.print("Relative Humidity : ");
  Serial.print(humidity);
  Serial.println(" %");*/
  
  delay(1000);
}

